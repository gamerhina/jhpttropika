# Scholar Citation Widget

Scholar Citation Widget is a lightweight, production-ready OJS 3.4.x generic plugin that displays Google Scholar citation metrics (Total Citations, h-index, i10-index) and a citation trend graph directly inside the OJS sidebar without slowing down your site or risking Google Scholar IP bans.

## Key Features

- **Performance-First Design**: Completely prevents N+1 queries. Never scrapes Google Scholar directly from PHP. Reads local JSON data generated asynchronously.
- **Modern UI**: Clean cards, beautiful animated Line Graph (using Chart.js), and responsive styles matching the latest theme roundings.
- **Easy Config**: Settings form available in OJS plugin settings to control Title, Highlight Color, Scholar ID, visibility of elements, and cache path.
- **Robust Cache**: Gracefully displays warnings if data is missing or corrupted, never crashing OJS.

---

## Architecture Overview

Google Scholar Page (External)  
&emsp;&emsp;↓  
**ScholarUpdater (Python CLI script)**  
&emsp;&emsp;↓ (writes)  
**citations.json (Local file)**  
&emsp;&emsp;↓ (reads)  
**Scholar Citation Widget (OJS PHP Plugin)**  

---

## Installation & Setup

### 1. PHP Plugin (OJS Side)

1. Put the `scholarCitationWidget/` folder inside your OJS directory: `plugins/generic/scholarCitationWidget/`.
2. Log into OJS as an administrator, go to **Settings > Website > Plugins**, find **Scholar Citation Widget**, and check the box to **Enable** it.
3. Click the arrow next to the plugin name, choose **Settings**, and enter your **Google Scholar ID** (e.g. `zCyDRywAAAAJ`). Save changes.
4. The plugin will automatically hook into your homepage sidebar, replacing the old static google scholar citation iframe block seamlessly.

### 2. Python Updater (Data Source Side)

To update the citation numbers, run the Python updater script periodically.

#### Installation:
```bash
cd plugins/generic/scholarCitationWidget/updater
pip install -r requirements.txt
```

#### Run command:
```bash
python updater.py --id YOUR_SCHOLAR_ID --output ../cache/citations.json
```
For example:
```bash
python updater.py --id zCyDRywAAAAJ --output "c:\laragon\www\jhpttropika\jhpttropika34\plugins\generic\scholarCitationWidget\cache\citations.json"
```

#### Automating Updates (Cron / Task Scheduler)
Set up a daily task to run the python command above. This guarantees that your sidebar citation count updates automatically every 24 hours without any website page slowdowns!
