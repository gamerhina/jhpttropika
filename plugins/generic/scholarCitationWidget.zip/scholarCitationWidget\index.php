<?php
/**
 * @file plugins/generic/scholarCitationWidget/index.php
 *
 * Copyright (c) 2026 Bihikmi
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @brief Wrapper for scholarCitationWidget plugin.
 *
 */
require_once('ScholarCitationWidgetPlugin.php');
return new ScholarCitationWidgetPlugin();
