import sys
import argparse
import json
import datetime
from parser import parse_with_bs4, parse_with_selenium

def save_json(data, output_path):
    output_data = {
        "profile": data["profile"],
        "metrics": data["metrics"],
        "chart": data["chart"],
        "updated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "generator": "ScholarUpdater"
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=4, ensure_ascii=False)

def main():
    parser = argparse.ArgumentParser(description="Update Google Scholar Citation Widget JSON Data")
    parser.add_argument("--id", required=True, help="Google Scholar User ID")
    parser.add_argument("--output", required=True, help="Path to output citations.json file")
    
    args = parser.parse_args()
    
    print(f"Starting Google Scholar update for ID: {args.id}")
    
    # Try BS4
    try:
        print("Attempting to fetch using BeautifulSoup4...")
        data = parse_with_bs4(args.id)
        save_json(data, args.output)
        print(f"Success! Data saved to {args.output}")
        sys.exit(0)
    except Exception as e:
        print(f"BeautifulSoup4 failed: {str(e)}")
        
    # Fallback to Selenium
    try:
        print("Falling back to Selenium...")
        data = parse_with_selenium(args.id)
        save_json(data, args.output)
        print(f"Success! Data saved to {args.output}")
        sys.exit(0)
    except Exception as e:
        print(f"Selenium fallback failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
