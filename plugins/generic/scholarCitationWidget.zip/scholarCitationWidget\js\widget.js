(function() {
    function initChart() {
        if (typeof Chart === 'undefined') {
            setTimeout(initChart, 50);
            return;
        }
        var dataEl = document.getElementById('scholarChartData');
        if (!dataEl) return;
        
        var chartDataRaw = dataEl.getAttribute('data-years');
        if (!chartDataRaw) return;
        
        var chartData;
        try {
            chartData = JSON.parse(chartDataRaw);
        } catch (e) {
            console.error('Failed to parse Scholar chart data', e);
            return;
        }
        
        var themeColor = dataEl.getAttribute('data-theme') || '#014401';
        
        var years = [];
        var citations = [];
        
        chartData.forEach(function(item) {
            years.push(item.year);
            citations.push(item.citations);
        });
        
        var canvas = document.getElementById('scholarSidebarChart');
        if (!canvas) return;
        
        var ctx = canvas.getContext('2d');
        
        // Create 10% opacity fill color
        var fillColor = themeColor;
        if (themeColor.startsWith('#')) {
            // Add '26' for ~15% opacity hex
            fillColor = themeColor + '26';
        }
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: years,
                datasets: [{
                    data: citations,
                    borderColor: themeColor,
                    backgroundColor: fillColor,
                    borderWidth: 2,
                    pointBackgroundColor: themeColor,
                    pointBorderColor: '#ffffff',
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    fill: true,
                    tension: 0.35
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: { size: 10 },
                        bodyFont: { size: 10 },
                        padding: 6,
                        displayColors: false
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { font: { size: 9 }, color: '#868e96' }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: '#e9ecef' },
                        ticks: { font: { size: 9 }, color: '#868e96', precision: 0 }
                    }
                }
            }
        });
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initChart);
    } else {
        initChart();
    }
})();
