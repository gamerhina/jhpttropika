<?php
/**
 * @file plugins/generic/scholarCitationWidget/ScholarCitationWidgetPlugin.php
 *
 * Copyright (c) 2026 Bihikmi
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @class ScholarCitationWidgetPlugin
 * @brief Scholar Citation Widget OJS plugin main class
 */

namespace APP\plugins\generic\scholarCitationWidget;

use APP\core\Application;
use APP\template\TemplateManager;
use PKP\core\JSONMessage;
use PKP\linkAction\LinkAction;
use PKP\linkAction\request\AjaxModal;
use PKP\plugins\GenericPlugin;
use PKP\plugins\Hook;

class ScholarCitationWidgetPlugin extends GenericPlugin
{
    /**
     * @copydoc Plugin::register()
     */
    public function register($category, $path, $mainContextId = null)
    {
        $success = parent::register($category, $path, $mainContextId);
        if (Application::isUnderMaintenance()) {
            return true;
        }
        if ($success && $this->getEnabled($mainContextId)) {
            // Apply output filter to inject the widget into the hardcoded sidebar block
            Hook::add('TemplateManager::display', [$this, 'registerSidebarFilter']);
        }
        return $success;
    }

    /**
     * @copydoc Plugin::getDisplayName()
     */
    public function getDisplayName()
    {
        return __('plugins.generic.scholarCitationWidget.displayName');
    }

    /**
     * @copydoc Plugin::getDescription()
     */
    public function getDescription()
    {
        return __('plugins.generic.scholarCitationWidget.description');
    }

    /**
     * @copydoc Plugin::getActions()
     */
    public function getActions($request, $verb)
    {
        $router = $request->getRouter();
        return array_merge(
            $this->getEnabled() ? [
                new LinkAction(
                    'settings',
                    new AjaxModal(
                        $router->url($request, null, null, 'manage', null, [
                            'verb' => 'settings',
                            'category' => 'generic',
                            'plugin' => $this->getName(),
                        ]),
                        $this->getDisplayName(),
                        'modal_edit'
                    ),
                    __('manager.plugins.settings'),
                    'edit'
                ),
            ] : [],
            parent::getActions($request, $verb)
        );
    }

    /**
     * @copydoc Plugin::manage()
     */
    public function manage($args, $request)
    {
        switch ($request->getUserVar('verb')) {
            case 'settings':
                $context = $request->getContext();
                $templateMgr = TemplateManager::getManager($request);
                $templateMgr->registerPlugin('function', 'plugin_url', [$this, 'smartyPluginUrl']);

                $form = new ScholarCitationWidgetSettingsForm($this, $context->getId());

                if ($request->getUserVar('save')) {
                    $form->readInputData();
                    if ($form->validate()) {
                        $form->execute();
                        return new JSONMessage(true);
                    }
                } else {
                    $form->initData();
                }
                return new JSONMessage(true, $form->fetch($request));
        }
        return parent::manage($args, $request);
    }

    /**
     * Hook into TemplateManager::display to register our output filter
     */
    public function registerSidebarFilter($hookName, $args)
    {
        $templateMgr = $args[0];
        $templateMgr->registerFilter('output', [$this, 'renderSidebarWidget']);
        return false;
    }

    /**
     * Smarty output filter to replace the hardcoded custom block with our styled widget
     */
    public function renderSidebarWidget($output, $templateMgr)
    {
        $request = Application::get()->getRequest();
        $context = $request->getContext();
        if (!$context) {
            return $output;
        }

        // 1. Check if the output contains our target customblock placeholder
        if (!str_contains($output, 'id="customblock-google-scholar-citations"')) {
            return $output;
        }

        // 2. Read citation JSON data
        $jsonData = $this->readCitationData($context->getId());
        
        // 3. Prepare template variables
        $themeColor = $this->getSetting($context->getId(), 'themeColor') ?? '#014401';
        $sidebarTitle = $this->getSetting($context->getId(), 'sidebarTitle') ?? 'Google Scholar';
        $showButton = $this->getSetting($context->getId(), 'showButton') ?? true;
        $showGraph = $this->getSetting($context->getId(), 'showGraph') ?? true;

        $templateMgr->assign([
            'scholarData' => $jsonData,
            'scholarThemeColor' => $themeColor,
            'scholarSidebarTitle' => $sidebarTitle,
            'scholarShowButton' => $showButton,
            'scholarShowGraph' => $showGraph,
            'scholarPluginPath' => $request->getBaseUrl() . '/' . $this->getPluginPath()
        ]);

        // 4. Render the sidebar widget template
        $widgetHtml = $templateMgr->fetch($this->getTemplateResource('sidebar.tpl'));

        // 5. Replace the target div block with our rendered widget HTML
        $pattern = '/<div class="pkp_block block_custom" id="customblock-google-scholar-citations">.*?<\/div>\s*<\/div>\s*<\/div>/s';
        $newOutput = preg_replace($pattern, $widgetHtml, $output);

        if ($newOutput) {
            return $newOutput;
        }

        return $output;
    }

    /**
     * Helper to load and validate citations JSON
     */
    private function readCitationData($contextId)
    {
        $customPath = $this->getSetting($contextId, 'jsonFileLocation');
        $filePath = !empty($customPath) ? $customPath : $this->getPluginPath() . '/cache/citations.json';

        if (!file_exists($filePath)) {
            return ['error' => __('plugins.generic.scholarCitationWidget.error.noData')];
        }

        $content = file_get_contents($filePath);
        $data = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE || !isset($data['profile']) || !isset($data['metrics'])) {
            return ['error' => __('plugins.generic.scholarCitationWidget.error.invalidJson')];
        }

        return $data;
    }
}

if (!PKP_STRICT_MODE) {
    class_alias('\APP\plugins\generic\scholarCitationWidget\ScholarCitationWidgetPlugin', '\ScholarCitationWidgetPlugin');
}
